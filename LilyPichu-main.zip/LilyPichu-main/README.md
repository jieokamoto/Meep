![Banner](https://nyri4.github.io/LilyPichu/assets/banner.png)

---

# LilyPichu
![Preview](https://nyri4.github.io/LilyPichu/assets/capture.png)

## 📥 Installation

### Powercord & Vizality

```sh
git clone https://github.com/NYRI4/LilyPichu
```

### BetterDiscord

1. Go [here](https://betterdiscord.app/Download?id=177)
2. Save the file into your theme folder

## 🖌️ Customization
Go into your theme folder
- For BetterDiscord : `lilypichu.theme.css`
- For Powercord/Vizality : `LilyPichu > stuff > _variables.scss`
